export default function Checkbox({
  id,
  label,
  required = false,
  error,
  ...props
}) {
  return (
    <div className="mb-4">
      <label
        htmlFor={id}
        className="flex items-center gap-2.5 text-sm font-medium text-slate-700 cursor-pointer select-none"
      >
        <input
          id={id}
          type="checkbox"
          className={`h-4 w-4 rounded border text-indigo-600 shadow-sm transition focus:outline-none focus:ring-4 ${
            error
              ? "border-red-400 focus:ring-red-100"
              : "border-slate-300 focus:ring-indigo-100"
          }`}
          {...props}
        />

        {label}

        {required && (
          <span className="text-red-500 ml-0.5">*</span>
        )}
      </label>

      {error && (
        <p className="text-red-500 text-xs mt-1 ml-6">
          {error}
        </p>
      )}
    </div>
  );
}