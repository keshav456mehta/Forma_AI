export default function Label({ htmlFor, children, text, required, inline }) {
  const base = inline
    ? "text-sm font-medium text-slate-700"
    : "block text-sm font-medium text-slate-700 mb-1.5";
  return (
    <label htmlFor={htmlFor} className={base}>
      {text ?? children}
      {required && <span className="text-red-500 ml-1">*</span>}
    </label>
  );
}